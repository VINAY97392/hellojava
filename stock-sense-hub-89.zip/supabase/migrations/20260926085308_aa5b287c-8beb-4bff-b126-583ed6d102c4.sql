-- Move the is_manager helper out of the API-exposed schema; policies keep working, direct calls are blocked
create schema if not exists private;

create or replace function private.is_manager()
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(auth.uid(), 'manager')
$$;

grant usage on schema private to authenticated;
grant execute on function private.is_manager() to authenticated;
revoke execute on function private.is_manager() from anon, public;

-- Repoint policies to private.is_manager, then drop the public one
drop policy if exists "managers write" on public.warehouses;
drop policy if exists "managers update" on public.warehouses;
drop policy if exists "managers delete" on public.warehouses;
create policy "managers write" on public.warehouses for insert to authenticated with check (private.is_manager());
create policy "managers update" on public.warehouses for update to authenticated using (private.is_manager()) with check (private.is_manager());
create policy "managers delete" on public.warehouses for delete to authenticated using (private.is_manager());

drop policy if exists "managers write" on public.locations;
drop policy if exists "managers update" on public.locations;
drop policy if exists "managers delete" on public.locations;
create policy "managers write" on public.locations for insert to authenticated with check (private.is_manager());
create policy "managers update" on public.locations for update to authenticated using (private.is_manager()) with check (private.is_manager());
create policy "managers delete" on public.locations for delete to authenticated using (private.is_manager());

drop policy if exists "managers write" on public.categories;
drop policy if exists "managers update" on public.categories;
drop policy if exists "managers delete" on public.categories;
create policy "managers write" on public.categories for insert to authenticated with check (private.is_manager());
create policy "managers update" on public.categories for update to authenticated using (private.is_manager()) with check (private.is_manager());
create policy "managers delete" on public.categories for delete to authenticated using (private.is_manager());

drop policy if exists "managers write" on public.products;
drop policy if exists "managers update" on public.products;
drop policy if exists "managers delete" on public.products;
create policy "managers write" on public.products for insert to authenticated with check (private.is_manager());
create policy "managers update" on public.products for update to authenticated using (private.is_manager()) with check (private.is_manager());
create policy "managers delete" on public.products for delete to authenticated using (private.is_manager());

drop policy if exists "team create" on public.documents;
drop policy if exists "team update" on public.documents;
drop policy if exists "managers delete drafts" on public.documents;
create policy "team create" on public.documents for insert to authenticated
  with check (doc_type <> 'adjustment' or private.is_manager());
create policy "team update" on public.documents for update to authenticated
  using (status not in ('done','canceled'))
  with check (
    (status <> 'canceled' or private.is_manager())
    and (doc_type <> 'adjustment' or private.is_manager())
  );
create policy "managers delete drafts" on public.documents for delete to authenticated
  using (private.is_manager() and status = 'draft');

drop policy if exists "team write lines" on public.document_lines;
drop policy if exists "team update lines" on public.document_lines;
drop policy if exists "team delete lines" on public.document_lines;
create policy "team write lines" on public.document_lines for insert to authenticated
  with check (exists (
    select 1 from public.documents d where d.id = document_id
      and d.status not in ('done','canceled')
      and (d.doc_type <> 'adjustment' or private.is_manager())
  ));
create policy "team update lines" on public.document_lines for update to authenticated
  using (exists (
    select 1 from public.documents d where d.id = document_id
      and d.status not in ('done','canceled')
      and (d.doc_type <> 'adjustment' or private.is_manager())
  ));
create policy "team delete lines" on public.document_lines for delete to authenticated
  using (exists (
    select 1 from public.documents d where d.id = document_id
      and d.status not in ('done','canceled')
      and (d.doc_type <> 'adjustment' or private.is_manager())
  ));

drop function public.is_manager();