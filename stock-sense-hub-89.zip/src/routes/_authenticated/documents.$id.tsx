import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Check, Trash2 } from "lucide-react";
import { AppShell, StatusBadge, selectCls, thCls } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { DOC_TYPES, fmtDate, useDocuments, useMaster, useProfiles, useRefresh, useRole, type DocStatus } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/documents/$id")({
  head: () => ({ meta: [
    { title: "Operation — StockSense" },
    { name: "description", content: "Edit and validate a stock operation." },
    { property: "og:title", content: "Operation — StockSense" },
    { property: "og:description", content: "Edit and validate a stock operation." },
  ] }),
  component: DocPage,
});

function DocPage() {
  const { id } = Route.useParams();
  const m = useMaster();
  const d = useDocuments();
  const pr = useProfiles();
  const { isManager } = useRole();
  const refresh = useRefresh();
  const [addPid, setAddPid] = useState("");
  const doc = d.data?.find((x) => x.id === id);
  if (!m.data || !d.data) return <AppShell title="Operation"><p className="text-muted-foreground">Loading…</p></AppShell>;
  if (!doc) return <AppShell title="Operation"><p>Document not found. <Link to="/dashboard" className="underline">Back to dashboard</Link></p></AppShell>;
  const { products, locations, locName, byLoc } = m.data;
  const t = DOC_TYPES.find((x) => x.type === doc.doc_type)!;
  const editable = doc.status !== "done" && doc.status !== "canceled" && (doc.doc_type !== "adjustment" || isManager);
  const needSrc = doc.doc_type === "delivery" || doc.doc_type === "internal";
  const needDst = doc.doc_type !== "delivery";
  const isAdj = doc.doc_type === "adjustment";
  const qtyAt = (pid: string, loc: string | null) => (loc ? byLoc[pid]?.[loc] ?? 0 : 0);

  async function patch(values: Database["public"]["Tables"]["documents"]["Update"]) {
    const r = await supabase.from("documents").update(values).eq("id", id);
    if (r.error) toast.error(r.error.message); else refresh();
  }
  async function setStatus(s: DocStatus) { await patch({ status: s }); }
  async function addLine() {
    if (!addPid) return;
    const r = await supabase.from("document_lines").insert({ document_id: id, product_id: addPid, quantity: isAdj ? 0 : 1, counted: isAdj ? qtyAt(addPid, doc!.dest_location_id) : null });
    if (r.error) toast.error(r.error.message); else { setAddPid(""); refresh(); }
  }
  async function updLine(lineId: string, values: { quantity?: number; counted?: number }) {
    const r = await supabase.from("document_lines").update(values).eq("id", lineId);
    if (r.error) toast.error(r.error.message); else refresh();
  }
  async function delLine(lineId: string) {
    const r = await supabase.from("document_lines").delete().eq("id", lineId);
    if (r.error) toast.error(r.error.message); else refresh();
  }
  async function validate() {
    const r = await supabase.rpc("validate_document", { _doc: id });
    if (r.error) return void toast.error(r.error.message);
    toast.success(`${doc!.reference} validated — stock updated`);
    refresh();
  }

  const steps: { s: DocStatus; label: string }[] = doc.doc_type === "delivery"
    ? [{ s: "draft", label: "Draft" }, { s: "waiting", label: "Pick" }, { s: "ready", label: "Pack" }, { s: "done", label: "Validated" }]
    : [{ s: "draft", label: "Draft" }, { s: "waiting", label: "Waiting" }, { s: "ready", label: "Ready" }, { s: "done", label: "Done" }];
  const idx = steps.findIndex((x) => x.s === doc.status);
  const next = doc.status === "draft" ? { s: "waiting" as const, label: doc.doc_type === "delivery" ? "Start picking" : "Mark as waiting" }
    : doc.status === "waiting" ? { s: "ready" as const, label: doc.doc_type === "delivery" ? "Items picked → Pack" : "Mark ready" } : null;

  return (
    <AppShell
      title={<span className="flex items-center gap-3"><Link to="/operations/$kind" params={{ kind: t.slug }} className="text-muted-foreground hover:underline">{t.label}</Link>/<span className="font-mono">{doc.reference}</span><StatusBadge status={doc.status} /></span>}
      actions={editable ? <>
        {isManager && <Button variant="ghost" onClick={() => setStatus("canceled")}>Cancel</Button>}
        {next && <Button variant="outline" onClick={() => setStatus(next.s)}>{next.label}</Button>}
        <Button onClick={validate}><Check className="h-4 w-4" />Validate</Button>
      </> : undefined}>
      <ol className="mb-6 flex flex-wrap gap-2">
        {steps.map((st, i) => (
          <li key={st.s} className={`flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium ${doc.status === "canceled" ? "opacity-40" : i <= idx ? "border-accent bg-accent/20" : "text-muted-foreground"}`}>
            <span className="font-mono">{i + 1}</span>{st.label}
          </li>
        ))}
      </ol>

      <div className="grid gap-4 rounded-lg border bg-card p-5 md:grid-cols-4">
        {(doc.doc_type === "receipt" || doc.doc_type === "delivery") && (
          <div><Label>{doc.doc_type === "receipt" ? "Supplier" : "Customer"}</Label>
            <Input disabled={!editable} defaultValue={doc.partner ?? ""} onBlur={(e) => e.target.value !== (doc.partner ?? "") && patch({ partner: e.target.value })} /></div>
        )}
        {needSrc && <div><Label>Source location</Label><LocSelect disabled={!editable} value={doc.source_location_id} onChange={(v) => patch({ source_location_id: v })} locations={locations} locName={locName} /></div>}
        {needDst && <div><Label>{isAdj ? "Location counted" : "Destination location"}</Label><LocSelect disabled={!editable} value={doc.dest_location_id} onChange={(v) => patch({ dest_location_id: v })} locations={locations} locName={locName} /></div>}
        <div><Label>Scheduled date</Label><Input type="date" disabled={!editable} value={doc.scheduled_date} onChange={(e) => patch({ scheduled_date: e.target.value })} /></div>
        <div className="md:col-span-4"><Label>Notes</Label><Input disabled={!editable} defaultValue={doc.notes ?? ""} onBlur={(e) => e.target.value !== (doc.notes ?? "") && patch({ notes: e.target.value })} placeholder={isAdj ? "e.g. 3 kg damaged in handling" : "Optional"} /></div>
      </div>

      <div className="mt-6 overflow-x-auto rounded-lg border bg-card">
        <table className="w-full text-sm">
          <thead className={thCls}><tr>
            <th className="p-3">Product</th>
            {isAdj ? <><th className="text-right">Recorded</th><th className="w-40 px-3">Counted</th><th className="text-right">Difference</th></>
              : <>{needSrc && <th className="text-right">Available at source</th>}<th className="w-40 px-3">Quantity</th></>}
            <th />
          </tr></thead>
          <tbody>
            {doc.document_lines.map((l) => {
              const p = products.find((x) => x.id === l.product_id);
              const rec = qtyAt(l.product_id, doc.dest_location_id);
              const avail = qtyAt(l.product_id, doc.source_location_id);
              const diff = Number(l.counted ?? rec) - rec;
              return (
                <tr key={l.id} className="border-t">
                  <td className="p-3"><span className="font-mono text-xs text-muted-foreground">{p?.sku}</span> {p?.name}</td>
                  {isAdj ? <>
                    <td className="text-right font-mono">{editable ? rec : "—"} {p?.uom}</td>
                    <td className="px-3 py-1.5"><Input type="number" min="0" className="h-8" disabled={!editable} defaultValue={l.counted ?? ""} onBlur={(e) => updLine(l.id, { counted: Number(e.target.value) })} /></td>
                    <td className={`text-right font-mono font-semibold ${!editable ? "" : diff < 0 ? "text-destructive" : diff > 0 ? "text-success" : "text-muted-foreground"}`}>{editable ? `${diff > 0 ? "+" : ""}${diff}` : "posted"}</td>
                  </> : <>
                    {needSrc && <td className={`text-right font-mono ${editable && avail < Number(l.quantity) ? "text-destructive" : ""}`}>{editable ? avail : "—"}</td>}
                    <td className="px-3 py-1.5"><div className="flex items-center gap-2"><Input type="number" min="0" className="h-8" disabled={!editable} defaultValue={Number(l.quantity)} onBlur={(e) => Number(e.target.value) !== Number(l.quantity) && updLine(l.id, { quantity: Number(e.target.value) })} /><span className="text-xs text-muted-foreground">{p?.uom}</span></div></td>
                  </>}
                  <td className="pr-3 text-right">{editable && <Button size="icon" variant="ghost" onClick={() => delLine(l.id)} aria-label="Remove line"><Trash2 className="h-4 w-4" /></Button>}</td>
                </tr>
              );
            })}
            {!doc.document_lines.length && <tr><td colSpan={5} className="p-6 text-center text-muted-foreground">No products yet — add one below.</td></tr>}
          </tbody>
        </table>
        {editable && (
          <div className="flex gap-2 border-t p-3">
            <select className={`${selectCls} max-w-sm`} value={addPid} onChange={(e) => setAddPid(e.target.value)}>
              <option value="">Add product…</option>
              {products.filter((p) => !doc.document_lines.some((l) => l.product_id === p.id)).map((p) => <option key={p.id} value={p.id}>{p.sku} — {p.name}</option>)}
            </select>
            <Button variant="outline" onClick={addLine} disabled={!addPid}>Add line</Button>
          </div>
        )}
      </div>
      <p className="mt-4 font-mono text-xs text-muted-foreground">
        Created {fmtDate(doc.created_at)}{doc.created_by && ` by ${pr.data?.find((p) => p.id === doc.created_by)?.full_name ?? "—"}`}
        {doc.validated_at && ` · Validated ${fmtDate(doc.validated_at)} by ${pr.data?.find((p) => p.id === doc.validated_by)?.full_name ?? "—"}`}
      </p>
    </AppShell>
  );
}

function LocSelect({ value, onChange, locations, locName, disabled }: { value: string | null; onChange: (v: string) => void; locations: { id: string }[]; locName: (id: string) => string; disabled?: boolean }) {
  return (
    <select className={selectCls} disabled={disabled} value={value ?? ""} onChange={(e) => onChange(e.target.value)}>
      <option value="" disabled>Select…</option>
      {locations.map((l) => <option key={l.id} value={l.id}>{locName(l.id)}</option>)}
    </select>
  );
}
