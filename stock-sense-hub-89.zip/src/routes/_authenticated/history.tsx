import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Download, Lock, Search } from "lucide-react";
import { AppShell, MoveBadge, selectCls, thCls } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { exportCsv, fmtDate, useMaster, useMoves, useProfiles } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/history")({
  head: () => ({ meta: [
    { title: "Move History — StockSense" },
    { name: "description", content: "The stock ledger: every validated movement, append-only." },
    { property: "og:title", content: "Move History — StockSense" },
    { property: "og:description", content: "The stock ledger: every validated movement, append-only." },
  ] }),
  component: History,
});

function History() {
  const m = useMaster();
  const mv = useMoves();
  const pr = useProfiles();
  const [q, setQ] = useState("");
  const [type, setType] = useState("all");
  const [wh, setWh] = useState("all");
  if (!m.data || !mv.data) return <AppShell title="Move History"><p className="text-muted-foreground">Loading…</p></AppShell>;
  const { products, locations, warehouses, locName } = m.data;
  const pById = Object.fromEntries(products.map((p) => [p.id, p]));
  const who = (id: string | null) => (id ? pr.data?.find((x) => x.id === id)?.full_name ?? "user" : "system");
  const rows = mv.data.filter((e) =>
    (type === "all" || e.move_type === type) &&
    (wh === "all" || locations.find((l) => l.id === e.location_id)?.warehouse_id === wh) &&
    `${pById[e.product_id]?.sku} ${pById[e.product_id]?.name} ${e.reference}`.toLowerCase().includes(q.toLowerCase()));

  return (
    <AppShell title="Move History" actions={
      <Button variant="outline" onClick={() => exportCsv("stock-ledger.csv", [["Date", "Type", "Reference", "SKU", "Product", "Location", "Qty", "User"], ...rows.map((e) => [e.created_at, e.move_type, e.reference, pById[e.product_id]?.sku, pById[e.product_id]?.name, locName(e.location_id), Number(e.quantity), who(e.user_id)])])}><Download className="h-4 w-4" />Export CSV</Button>
    }>
      <div className="mb-4 flex items-center gap-2 rounded-md border border-dashed bg-muted/40 p-3 text-xs text-muted-foreground"><Lock className="h-3.5 w-3.5" />Ledger entries are created only by validating an operation and can never be edited or deleted.</div>
      <div className="mb-4 flex flex-wrap gap-3">
        <div className="relative w-full max-w-xs"><Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><Input className="pl-9" placeholder="Search SKU, product, reference…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <select className={`${selectCls} w-44`} value={type} onChange={(e) => setType(e.target.value)}>
          <option value="all">All types</option>{["initial", "receipt", "delivery", "internal", "adjustment"].map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <select className={`${selectCls} w-44`} value={wh} onChange={(e) => setWh(e.target.value)}>
          <option value="all">All warehouses</option>{warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
        </select>
      </div>
      <div className="overflow-x-auto rounded-lg border bg-card">
        <table className="w-full text-sm">
          <thead className={thCls}><tr><th className="p-3">Date</th><th>Type</th><th>Reference</th><th>Product</th><th>Location</th><th className="text-right">Δ Qty</th><th className="p-3">User</th></tr></thead>
          <tbody>
            {rows.map((e) => {
              const qn = Number(e.quantity);
              return (
                <tr key={e.id} className="border-t">
                  <td className="p-3 font-mono text-xs text-muted-foreground">{fmtDate(e.created_at)}</td>
                  <td><MoveBadge type={e.move_type} /></td>
                  <td className="font-mono text-xs">{e.document_id ? <Link to="/documents/$id" params={{ id: e.document_id }} className="underline">{e.reference}</Link> : e.reference}</td>
                  <td><span className="font-mono text-xs text-muted-foreground">{pById[e.product_id]?.sku}</span> {pById[e.product_id]?.name}</td>
                  <td className="text-xs">{locName(e.location_id)}</td>
                  <td className={`text-right font-mono font-semibold ${qn > 0 ? "text-success" : "text-destructive"}`}>{qn > 0 ? "+" : ""}{qn} <span className="font-normal text-muted-foreground">{pById[e.product_id]?.uom}</span></td>
                  <td className="p-3 text-xs">{who(e.user_id)}</td>
                </tr>
              );
            })}
            {!rows.length && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No movements match.</td></tr>}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
