import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { AlertTriangle } from "lucide-react";
import { AppShell, Stat, StatusBadge, selectCls, thCls } from "@/components/AppShell";
import { DOC_TYPES, STATUSES, useDocuments, useMaster } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [
    { title: "Inventory Dashboard — StockSense" },
    { name: "description", content: "Snapshot of stock levels, pending receipts, deliveries and transfers." },
    { property: "og:title", content: "Inventory Dashboard — StockSense" },
    { property: "og:description", content: "Snapshot of stock levels, pending receipts, deliveries and transfers." },
  ] }),
  component: Dashboard,
});

const open = (s: string) => s !== "done" && s !== "canceled";

function Dashboard() {
  const m = useMaster();
  const d = useDocuments();
  const [type, setType] = useState("all");
  const [status, setStatus] = useState("all");
  const [wh, setWh] = useState("all");
  const [cat, setCat] = useState("all");

  if (!m.data || !d.data) return <AppShell title="Inventory Dashboard"><p className="text-muted-foreground">{m.error?.message ?? d.error?.message ?? "Loading…"}</p></AppShell>;
  const { products, onHand, warehouses, categories, locations, locName } = m.data;
  const docs = d.data;

  const inStock = products.filter((p) => (onHand[p.id] ?? 0) > 0).length;
  const out = products.filter((p) => (onHand[p.id] ?? 0) <= 0);
  const low = products.filter((p) => { const q = onHand[p.id] ?? 0; return q > 0 && q <= Number(p.reorder_min); });
  const pendR = docs.filter((x) => x.doc_type === "receipt" && open(x.status)).length;
  const pendD = docs.filter((x) => x.doc_type === "delivery" && open(x.status)).length;
  const pendI = docs.filter((x) => x.doc_type === "internal" && open(x.status)).length;

  const whOf = (locId: string | null) => locations.find((l) => l.id === locId)?.warehouse_id;
  const filtered = docs.filter((x) =>
    (type === "all" || x.doc_type === type) && (status === "all" || x.status === status) &&
    (wh === "all" || whOf(x.source_location_id) === wh || whOf(x.dest_location_id) === wh) &&
    (cat === "all" || x.document_lines.some((l) => products.find((p) => p.id === l.product_id)?.category_id === cat)));

  return (
    <AppShell title="Inventory Dashboard">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <Stat label="Products in stock" value={inStock} hint={`of ${products.length} products`} />
        <Stat label="Low / Out of stock" value={`${low.length} / ${out.length}`} tone={low.length + out.length ? "warn" : "ok"} hint="below reorder minimum" />
        <Stat label="Pending receipts" value={pendR} hint="not yet validated" />
        <Stat label="Pending deliveries" value={pendD} hint="to pick, pack & ship" />
        <Stat label="Transfers scheduled" value={pendI} hint="internal moves" />
      </div>

      {(low.length > 0 || out.length > 0) && (
        <div className="mt-6 rounded-lg border border-destructive/30 bg-destructive/5 p-4">
          <div className="flex items-center gap-2 font-semibold text-destructive"><AlertTriangle className="h-4 w-4" />Stock alerts</div>
          <div className="mt-2 flex flex-wrap gap-2 text-sm">
            {[...out, ...low].map((p) => (
              <Link key={p.id} to="/products" className="rounded border bg-card px-2 py-1">
                <span className="font-mono text-xs text-muted-foreground">{p.sku}</span> {p.name} · <b>{onHand[p.id] ?? 0}</b> {p.uom} (min {Number(p.reorder_min)})
              </Link>
            ))}
          </div>
        </div>
      )}

      <section className="mt-6 rounded-lg border bg-card">
        <div className="flex flex-wrap items-end gap-3 p-5">
          <h2 className="mr-auto font-semibold">Operations</h2>
          <Filter label="Document type" value={type} onChange={setType} options={DOC_TYPES.map((t) => [t.type, t.label])} />
          <Filter label="Status" value={status} onChange={setStatus} options={STATUSES.map((s) => [s, s[0]!.toUpperCase() + s.slice(1)])} />
          <Filter label="Warehouse" value={wh} onChange={setWh} options={warehouses.map((w) => [w.id, w.name])} />
          <Filter label="Category" value={cat} onChange={setCat} options={categories.map((c) => [c.id, c.name])} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className={thCls}><tr><th className="p-3">Reference</th><th>Type</th><th>Partner</th><th>From</th><th>To</th><th>Scheduled</th><th className="p-3">Status</th></tr></thead>
            <tbody>
              {filtered.map((x) => (
                <tr key={x.id} className="border-t hover:bg-muted/40">
                  <td className="p-3 font-mono text-xs"><Link to="/documents/$id" params={{ id: x.id }} className="underline">{x.reference}</Link></td>
                  <td className="capitalize">{DOC_TYPES.find((t) => t.type === x.doc_type)?.short}</td>
                  <td>{x.partner ?? "—"}</td>
                  <td className="text-xs text-muted-foreground">{x.source_location_id ? locName(x.source_location_id) : "Vendor"}</td>
                  <td className="text-xs text-muted-foreground">{x.dest_location_id ? locName(x.dest_location_id) : "Customer"}</td>
                  <td className="font-mono text-xs">{x.scheduled_date}</td>
                  <td className="p-3"><StatusBadge status={x.status} /></td>
                </tr>
              ))}
              {!filtered.length && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No documents match these filters.</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </AppShell>
  );
}

function Filter({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: [string, string][] }) {
  return (
    <label className="text-xs text-muted-foreground">{label}
      <select className={`${selectCls} mt-1 w-40`} value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="all">All</option>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </label>
  );
}
