<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- StockSense data lives in Lovable Cloud; stock is derived from the append-only stock_moves table, written only by the validate_document / set_initial_stock DB functions. Why: atomic stock checks and an immutable ledger.
- Signed-in pages live under src/routes/_authenticated and query via the browser client with react-query hooks in src/lib/data.ts. Why: team-shared data with RLS, no custom server code needed.
