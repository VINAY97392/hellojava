import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Boxes } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { selectCls } from "@/components/AppShell";

type Mode = "signin" | "signup" | "forgot" | "otp";

export const Route = createFileRoute("/auth")({
  validateSearch: z.object({ mode: z.enum(["signin", "signup"]).optional() }),
  head: () => ({ meta: [
    { title: "Sign in — StockSense" },
    { name: "description", content: "Sign in or create your StockSense account." },
    { property: "og:title", content: "Sign in — StockSense" },
    { property: "og:description", content: "Sign in or create your StockSense account." },
  ] }),
  component: AuthPage,
});

function AuthPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>(search.mode ?? "signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState("staff");
  const [otp, setOtp] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { if (data.session && mode !== "otp") navigate({ to: "/dashboard", replace: true }); });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function run(fn: () => Promise<void>) {
    setBusy(true);
    try { await fn(); } catch (e) { toast.error(e instanceof Error ? e.message : "Something went wrong"); } finally { setBusy(false); }
  }

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    run(async () => {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/dashboard" });
      } else if (mode === "signup") {
        if (password.length < 8) throw new Error("Password must be at least 8 characters");
        const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin, data: { full_name: name, role } } });
        if (error) throw error;
        if (data.session) navigate({ to: "/dashboard" });
        else { toast.success("Check your email to confirm your account."); setMode("signin"); }
      } else if (mode === "forgot") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
        if (error) throw error;
        toast.success("We sent a reset code to your email.");
        setMode("otp");
      } else {
        const { error } = await supabase.auth.verifyOtp({ email, token: otp.trim(), type: "recovery" });
        if (error) throw error;
        if (password.length < 8) throw new Error("New password must be at least 8 characters");
        const up = await supabase.auth.updateUser({ password });
        if (up.error) throw up.error;
        toast.success("Password updated");
        navigate({ to: "/dashboard" });
      }
    });
  };

  const google = () => run(async () => {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) throw r.error;
    if (r.redirected) return;
    navigate({ to: "/dashboard" });
  });

  const titles: Record<Mode, string> = { signin: "Welcome back", signup: "Create your account", forgot: "Reset password", otp: "Enter reset code" };

  return (
    <div className="grid min-h-screen place-items-center bg-background px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex items-center gap-2"><div className="grid h-9 w-9 place-items-center rounded-md bg-accent text-accent-foreground"><Boxes className="h-5 w-5" /></div><span className="text-lg font-bold">StockSense</span></div>
        <h1 className="text-2xl font-bold">{titles[mode]}</h1>
        <form onSubmit={submit} className="mt-6 space-y-3">
          {mode === "signup" && (<>
            <div><Label>Full name</Label><Input required value={name} onChange={(e) => setName(e.target.value)} /></div>
            <div><Label>Role</Label><select className={selectCls} value={role} onChange={(e) => setRole(e.target.value)}><option value="manager">Inventory Manager</option><option value="staff">Warehouse Staff</option></select></div>
          </>)}
          <div><Label>Email</Label><Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} disabled={mode === "otp"} /></div>
          {mode === "otp" && <div><Label>Code from email</Label><Input required inputMode="numeric" value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="6-digit code" /></div>}
          {mode !== "forgot" && <div><Label>{mode === "otp" ? "New password" : "Password"}</Label><Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>}
          <Button type="submit" className="w-full" disabled={busy}>{mode === "signin" ? "Sign in" : mode === "signup" ? "Create account" : mode === "forgot" ? "Send reset code" : "Verify & set password"}</Button>
        </form>
        {(mode === "signin" || mode === "signup") && (<>
          <div className="my-4 text-center text-xs text-muted-foreground">or</div>
          <Button variant="outline" className="w-full" onClick={google} disabled={busy}>Continue with Google</Button>
        </>)}
        <div className="mt-6 space-y-1 text-center text-sm text-muted-foreground">
          {mode === "signin" && <>
            <button className="underline" onClick={() => setMode("forgot")}>Forgot password?</button>
            <div>New here? <button className="underline" onClick={() => setMode("signup")}>Create an account</button></div>
          </>}
          {mode !== "signin" && <button className="underline" onClick={() => setMode("signin")}>Back to sign in</button>}
        </div>
      </div>
    </div>
  );
}
