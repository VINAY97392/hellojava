
create type public.app_role as enum ('manager','staff');
create type public.doc_type as enum ('receipt','delivery','internal','adjustment');
create type public.doc_status as enum ('draft','waiting','ready','done','canceled');

create table public.warehouses (id uuid primary key default gen_random_uuid(), name text not null, code text not null unique, address text, created_at timestamptz not null default now());
create table public.locations (id uuid primary key default gen_random_uuid(), warehouse_id uuid not null references public.warehouses(id) on delete cascade, name text not null, created_at timestamptz not null default now());
create table public.categories (id uuid primary key default gen_random_uuid(), name text not null unique);
create table public.products (
  id uuid primary key default gen_random_uuid(), sku text not null unique, name text not null,
  category_id uuid references public.categories(id) on delete set null, uom text not null default 'pcs',
  unit_cost numeric not null default 0, reorder_min numeric not null default 0, reorder_qty numeric not null default 0,
  created_at timestamptz not null default now());
create table public.profiles (id uuid primary key, full_name text, default_warehouse_id uuid references public.warehouses(id) on delete set null, created_at timestamptz not null default now());
create table public.user_roles (id uuid primary key default gen_random_uuid(), user_id uuid not null, role public.app_role not null, unique(user_id, role));
create table public.documents (
  id uuid primary key default gen_random_uuid(), doc_type public.doc_type not null, status public.doc_status not null default 'draft',
  reference text unique, partner text, source_location_id uuid references public.locations(id), dest_location_id uuid references public.locations(id),
  scheduled_date date not null default current_date, notes text, created_by uuid, created_at timestamptz not null default now(), validated_at timestamptz);
create table public.document_lines (
  id uuid primary key default gen_random_uuid(), document_id uuid not null references public.documents(id) on delete cascade,
  product_id uuid not null references public.products(id), quantity numeric not null default 0, counted numeric);
create table public.stock_moves (
  id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(),
  product_id uuid not null references public.products(id), location_id uuid not null references public.locations(id),
  quantity numeric not null, move_type text not null, reference text, document_id uuid references public.documents(id), user_id uuid);

grant select, insert, update, delete on public.warehouses, public.locations, public.categories, public.products, public.documents, public.document_lines to authenticated;
grant select, update on public.profiles to authenticated;
grant select on public.user_roles, public.stock_moves to authenticated;
grant all on public.warehouses, public.locations, public.categories, public.products, public.documents, public.document_lines, public.profiles, public.user_roles, public.stock_moves to service_role;

alter table public.warehouses enable row level security;
alter table public.locations enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.documents enable row level security;
alter table public.document_lines enable row level security;
alter table public.stock_moves enable row level security;

create policy "team all" on public.warehouses for all to authenticated using (true) with check (true);
create policy "team all" on public.locations for all to authenticated using (true) with check (true);
create policy "team all" on public.categories for all to authenticated using (true) with check (true);
create policy "team all" on public.products for all to authenticated using (true) with check (true);
create policy "team all" on public.documents for all to authenticated using (true) with check (true);
create policy "team all" on public.document_lines for all to authenticated using (true) with check (true);
create policy "team read" on public.stock_moves for select to authenticated using (true);
create policy "team read" on public.profiles for select to authenticated using (true);
create policy "own update" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "team read" on public.user_roles for select to authenticated using (true);

create view public.stock_levels with (security_invoker = on) as
  select product_id, location_id, sum(quantity) as quantity from public.stock_moves group by product_id, location_id;
grant select on public.stock_levels to authenticated;

create or replace function public.has_role(_user_id uuid, _role public.app_role) returns boolean
language sql stable security definer set search_path = public as $$ select exists (select 1 from public.user_roles where user_id=_user_id and role=_role) $$;

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare r text := coalesce(new.raw_user_meta_data->>'role','staff'); wh uuid;
begin
  begin wh := nullif(new.raw_user_meta_data->>'default_warehouse_id','')::uuid; exception when others then wh := null; end;
  insert into public.profiles(id, full_name, default_warehouse_id) values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), wh);
  insert into public.user_roles(user_id, role) values (new.id, case when r='manager' then 'manager'::public.app_role else 'staff'::public.app_role end);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create sequence public.doc_seq_receipt; create sequence public.doc_seq_delivery; create sequence public.doc_seq_internal; create sequence public.doc_seq_adjustment;
create or replace function public.set_doc_reference() returns trigger language plpgsql set search_path = public as $$
begin
  if new.reference is null then
    new.reference := case new.doc_type
      when 'receipt' then 'WH/IN/' || lpad(nextval('public.doc_seq_receipt')::text,4,'0')
      when 'delivery' then 'WH/OUT/' || lpad(nextval('public.doc_seq_delivery')::text,4,'0')
      when 'internal' then 'WH/INT/' || lpad(nextval('public.doc_seq_internal')::text,4,'0')
      else 'WH/ADJ/' || lpad(nextval('public.doc_seq_adjustment')::text,4,'0') end;
  end if;
  if new.created_by is null then new.created_by := auth.uid(); end if;
  return new;
end $$;
create trigger documents_ref before insert on public.documents for each row execute function public.set_doc_reference();

create or replace function public.lock_done_documents() returns trigger language plpgsql set search_path = public as $$
begin
  if tg_op = 'UPDATE' and old.status in ('done','canceled') and current_setting('app.validating', true) is distinct from 'on' then
    raise exception 'Document % is % and can no longer be changed', old.reference, old.status;
  end if;
  if tg_op = 'DELETE' and old.status = 'done' then raise exception 'Validated documents cannot be deleted'; end if;
  return coalesce(new, old);
end $$;
create trigger documents_lock before update or delete on public.documents for each row execute function public.lock_done_documents();

create or replace function public.lock_done_lines() returns trigger language plpgsql set search_path = public as $$
declare s public.doc_status;
begin
  select status into s from public.documents where id = coalesce(new.document_id, old.document_id);
  if s in ('done','canceled') then raise exception 'Lines of a closed document cannot be changed'; end if;
  return coalesce(new, old);
end $$;
create trigger lines_lock before insert or update or delete on public.document_lines for each row execute function public.lock_done_lines();

create or replace function public.on_hand(_product uuid, _location uuid) returns numeric language sql stable security definer set search_path = public as $$
  select coalesce(sum(quantity),0) from public.stock_moves where product_id=_product and location_id=_location $$;

create or replace function public.validate_document(_doc uuid) returns void language plpgsql security definer set search_path = public as $$
declare d public.documents; l record; cur numeric; delta numeric;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  select * into d from public.documents where id=_doc for update;
  if not found then raise exception 'Document not found'; end if;
  if d.status in ('done','canceled') then raise exception 'Document is already %', d.status; end if;
  if not exists (select 1 from public.document_lines where document_id=_doc) then raise exception 'Add at least one product line'; end if;
  if d.doc_type in ('receipt','internal','adjustment') and d.dest_location_id is null then raise exception 'Destination location required'; end if;
  if d.doc_type in ('delivery','internal') and d.source_location_id is null then raise exception 'Source location required'; end if;
  for l in select dl.*, p.sku from public.document_lines dl join public.products p on p.id=dl.product_id where dl.document_id=_doc loop
    if d.doc_type = 'adjustment' then
      if l.counted is null then raise exception 'Enter counted quantity for %', l.sku; end if;
      cur := public.on_hand(l.product_id, d.dest_location_id); delta := l.counted - cur;
      if delta <> 0 then insert into public.stock_moves(product_id,location_id,quantity,move_type,reference,document_id,user_id) values (l.product_id,d.dest_location_id,delta,'adjustment',d.reference,_doc,auth.uid()); end if;
    else
      if l.quantity <= 0 then raise exception 'Quantity for % must be positive', l.sku; end if;
      if d.doc_type in ('delivery','internal') then
        cur := public.on_hand(l.product_id, d.source_location_id);
        if cur < l.quantity then raise exception 'Not enough % at source: % available, % requested', l.sku, cur, l.quantity; end if;
        insert into public.stock_moves(product_id,location_id,quantity,move_type,reference,document_id,user_id) values (l.product_id,d.source_location_id,-l.quantity,d.doc_type::text,d.reference,_doc,auth.uid());
      end if;
      if d.doc_type in ('receipt','internal') then
        insert into public.stock_moves(product_id,location_id,quantity,move_type,reference,document_id,user_id) values (l.product_id,d.dest_location_id,l.quantity,d.doc_type::text,d.reference,_doc,auth.uid());
      end if;
    end if;
  end loop;
  perform set_config('app.validating','on',true);
  update public.documents set status='done', validated_at=now() where id=_doc;
  perform set_config('app.validating','off',true);
end $$;
revoke execute on function public.validate_document(uuid) from public, anon;
grant execute on function public.validate_document(uuid) to authenticated;

create or replace function public.set_initial_stock(_product uuid, _location uuid, _qty numeric) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  if _qty <= 0 then return; end if;
  if exists (select 1 from public.stock_moves where product_id=_product) then raise exception 'Product already has stock history'; end if;
  insert into public.stock_moves(product_id,location_id,quantity,move_type,reference,user_id) values (_product,_location,_qty,'initial','INITIAL',auth.uid());
end $$;
revoke execute on function public.set_initial_stock(uuid,uuid,numeric) from public, anon;
grant execute on function public.set_initial_stock(uuid,uuid,numeric) to authenticated;

-- Demo data
insert into public.warehouses(id,name,code,address) values
 ('11111111-0000-0000-0000-000000000001','Main Warehouse','WH','Plot 12, Industrial Area'),
 ('11111111-0000-0000-0000-000000000002','Warehouse 2','WH2','Sector 5, Logistics Park');
insert into public.locations(id,warehouse_id,name) values
 ('22222222-0000-0000-0000-000000000001','11111111-0000-0000-0000-000000000001','Main Store'),
 ('22222222-0000-0000-0000-000000000002','11111111-0000-0000-0000-000000000001','Rack A'),
 ('22222222-0000-0000-0000-000000000003','11111111-0000-0000-0000-000000000001','Rack B'),
 ('22222222-0000-0000-0000-000000000004','11111111-0000-0000-0000-000000000001','Production Floor'),
 ('22222222-0000-0000-0000-000000000005','11111111-0000-0000-0000-000000000002','WH2 Stock');
insert into public.categories(id,name) values
 ('33333333-0000-0000-0000-000000000001','Raw Material'),('33333333-0000-0000-0000-000000000002','Furniture'),
 ('33333333-0000-0000-0000-000000000003','Hardware'),('33333333-0000-0000-0000-000000000004','Packaging');
insert into public.products(id,sku,name,category_id,uom,unit_cost,reorder_min,reorder_qty) values
 ('44444444-0000-0000-0000-000000000001','RM-STEEL','Steel','33333333-0000-0000-0000-000000000001','kg',1.2,50,200),
 ('44444444-0000-0000-0000-000000000002','RM-ROD','Steel Rods','33333333-0000-0000-0000-000000000001','pcs',4.5,40,100),
 ('44444444-0000-0000-0000-000000000003','FR-CHAIR','Office Chair','33333333-0000-0000-0000-000000000002','pcs',38,15,30),
 ('44444444-0000-0000-0000-000000000004','FR-DESK','Work Desk','33333333-0000-0000-0000-000000000002','pcs',120,5,10),
 ('44444444-0000-0000-0000-000000000005','HW-BOLT','Bolts M8','33333333-0000-0000-0000-000000000003','box',8.9,20,50),
 ('44444444-0000-0000-0000-000000000006','PK-BOX','Carton Box L','33333333-0000-0000-0000-000000000004','pcs',0.8,100,500);
insert into public.stock_moves(product_id,location_id,quantity,move_type,reference,created_at) values
 ('44444444-0000-0000-0000-000000000001','22222222-0000-0000-0000-000000000001',180,'initial','INITIAL',now()-interval '20 days'),
 ('44444444-0000-0000-0000-000000000001','22222222-0000-0000-0000-000000000004',40,'initial','INITIAL',now()-interval '20 days'),
 ('44444444-0000-0000-0000-000000000002','22222222-0000-0000-0000-000000000002',30,'initial','INITIAL',now()-interval '20 days'),
 ('44444444-0000-0000-0000-000000000003','22222222-0000-0000-0000-000000000003',60,'initial','INITIAL',now()-interval '20 days'),
 ('44444444-0000-0000-0000-000000000003','22222222-0000-0000-0000-000000000005',12,'initial','INITIAL',now()-interval '20 days'),
 ('44444444-0000-0000-0000-000000000004','22222222-0000-0000-0000-000000000005',4,'initial','INITIAL',now()-interval '20 days'),
 ('44444444-0000-0000-0000-000000000005','22222222-0000-0000-0000-000000000002',75,'initial','INITIAL',now()-interval '20 days');
insert into public.documents(id,doc_type,status,partner,source_location_id,dest_location_id,scheduled_date) values
 ('55555555-0000-0000-0000-000000000001','receipt','ready','Tata Steel Ltd',null,'22222222-0000-0000-0000-000000000001',current_date),
 ('55555555-0000-0000-0000-000000000002','receipt','waiting','PackRight Supplies',null,'22222222-0000-0000-0000-000000000001',current_date+2),
 ('55555555-0000-0000-0000-000000000003','delivery','ready','Acme Offices','22222222-0000-0000-0000-000000000003',null,current_date),
 ('55555555-0000-0000-0000-000000000004','delivery','draft','Blue Desk Co','22222222-0000-0000-0000-000000000005',null,current_date+1),
 ('55555555-0000-0000-0000-000000000005','internal','ready',null,'22222222-0000-0000-0000-000000000001','22222222-0000-0000-0000-000000000004',current_date+1);
insert into public.document_lines(document_id,product_id,quantity) values
 ('55555555-0000-0000-0000-000000000001','44444444-0000-0000-0000-000000000001',100),
 ('55555555-0000-0000-0000-000000000001','44444444-0000-0000-0000-000000000002',50),
 ('55555555-0000-0000-0000-000000000002','44444444-0000-0000-0000-000000000006',500),
 ('55555555-0000-0000-0000-000000000003','44444444-0000-0000-0000-000000000003',10),
 ('55555555-0000-0000-0000-000000000004','44444444-0000-0000-0000-000000000004',2),
 ('55555555-0000-0000-0000-000000000005','44444444-0000-0000-0000-000000000001',60);
