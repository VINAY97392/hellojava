import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AppShell, selectCls } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useMaster, useProfiles, useRefresh } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({ meta: [
    { title: "My Profile — StockSense" },
    { name: "description", content: "Your name, role and default warehouse." },
    { property: "og:title", content: "My Profile — StockSense" },
    { property: "og:description", content: "Your name, role and default warehouse." },
  ] }),
  component: Profile,
});

function Profile() {
  const { user } = Route.useRouteContext();
  const pr = useProfiles();
  const m = useMaster();
  const refresh = useRefresh();
  const me = pr.data?.find((p) => p.id === user.id);
  const [name, setName] = useState("");
  const [wh, setWh] = useState("");
  const [pw, setPw] = useState("");
  const [curPw, setCurPw] = useState("");
  useEffect(() => { if (me) { setName(me.full_name ?? ""); setWh(me.default_warehouse_id ?? ""); } }, [me]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const r = await supabase.from("profiles").update({ full_name: name.trim(), default_warehouse_id: wh || null }).eq("id", user.id);
    if (r.error) return void toast.error(r.error.message);
    toast.success("Profile saved"); refresh();
  }
  async function changePw(e: React.FormEvent) {
    e.preventDefault();
    if (pw.length < 8) return void toast.error("At least 8 characters");
    const r = await supabase.auth.updateUser({ password: pw, current_password: curPw } as { password: string });
    if (r.error) return void toast.error(r.error.message);
    setPw(""); setCurPw(""); toast.success("Password changed");
  }

  return (
    <AppShell title="My Profile">
      <div className="grid max-w-3xl gap-6 md:grid-cols-2">
        <form onSubmit={save} className="space-y-3 rounded-lg border bg-card p-5">
          <h2 className="font-semibold">Details</h2>
          <div><Label>Email</Label><Input value={user.email ?? ""} disabled /></div>
          <div><Label>Full name</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
          <div><Label>Role</Label><Input value={me?.role === "manager" ? "Inventory Manager" : "Warehouse Staff"} disabled /></div>
          <div><Label>Default warehouse</Label>
            <select className={selectCls} value={wh} onChange={(e) => setWh(e.target.value)}>
              <option value="">— None —</option>{m.data?.warehouses.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
            </select>
          </div>
          <Button type="submit">Save</Button>
        </form>
        <form onSubmit={changePw} className="space-y-3 rounded-lg border bg-card p-5">
          <h2 className="font-semibold">Change password</h2>
          <div><Label>Current password</Label><Input type="password" value={curPw} onChange={(e) => setCurPw(e.target.value)} /></div>
          <div><Label>New password</Label><Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></div>
          <Button type="submit" variant="outline">Update password</Button>
        </form>
      </div>
    </AppShell>
  );
}
