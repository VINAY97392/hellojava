import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard, Package, ArrowDownToLine, ArrowUpFromLine, ArrowLeftRight, ClipboardCheck,
  History, Warehouse, UserRound, LogOut, Boxes,
} from "lucide-react";
import type { ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useRole, type DocStatus } from "@/lib/data";

type NavItem = { to: "/dashboard" | "/products" | "/operations/$kind" | "/history" | "/warehouses" | "/profile"; kind?: string; label: string; icon: typeof Package };
const groups: { title: string | null; items: NavItem[] }[] = [
  { title: null, items: [{ to: "/dashboard", label: "Dashboard", icon: LayoutDashboard }, { to: "/products", label: "Products", icon: Package }] },
  { title: "Operations", items: [
    { to: "/operations/$kind", kind: "receipts", label: "Receipts", icon: ArrowDownToLine },
    { to: "/operations/$kind", kind: "deliveries", label: "Delivery Orders", icon: ArrowUpFromLine },
    { to: "/operations/$kind", kind: "transfers", label: "Internal Transfers", icon: ArrowLeftRight },
    { to: "/operations/$kind", kind: "adjustments", label: "Adjustments", icon: ClipboardCheck },
    { to: "/history", label: "Move History", icon: History },
  ] },
  { title: "Settings", items: [{ to: "/warehouses", label: "Warehouses", icon: Warehouse }] },
  { title: "Profile", items: [{ to: "/profile", label: "My Profile", icon: UserRound }] },
];

export function AppShell({ title, actions, children }: { title: ReactNode; actions?: ReactNode; children: ReactNode }) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { role } = useRole();
  const visible = groups.map((g) => ({
    ...g,
    items: g.items.filter((n) => n.to !== "/warehouses" || role === "manager"),
  }));
  async function logout() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }
  const linkCls = "flex items-center gap-3 rounded-md px-3 py-2 text-sm opacity-70 transition hover:bg-primary-foreground/10 hover:opacity-100";
  return (
    <div className="flex min-h-screen bg-background">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col overflow-y-auto bg-primary text-primary-foreground md:flex">
        <div className="flex items-center gap-2 px-5 py-6">
          <div className="grid h-9 w-9 place-items-center rounded-md bg-accent text-accent-foreground"><Boxes className="h-5 w-5" /></div>
          <div><div className="text-lg font-bold leading-none">StockSense</div><div className="font-mono text-[10px] uppercase tracking-widest opacity-60">Inventory OS</div></div>
        </div>
        <nav className="flex flex-col gap-4 px-3 pb-4">
          {visible.map((g, i) => (
            <div key={i} className="flex flex-col gap-0.5">
              {g.title && <div className="px-3 pb-1 font-mono text-[10px] uppercase tracking-widest opacity-50">{g.title}</div>}
              {g.items.map((n) => (
                <Link key={n.label} to={n.to} params={{ kind: n.kind ?? "" }} className={linkCls} activeProps={{ className: "!opacity-100 bg-primary-foreground/10" }}>
                  <n.icon className="h-4 w-4" />{n.label}
                </Link>
              ))}
              {g.title === "Profile" && <button onClick={logout} className={linkCls}><LogOut className="h-4 w-4" />Logout</button>}
            </div>
          ))}
        </nav>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <nav className="flex gap-1 overflow-x-auto border-b bg-card px-2 py-2 md:hidden">
          {visible.flatMap((g) => g.items).map((n) => (
            <Link key={n.label} to={n.to} params={{ kind: n.kind ?? "" }} className="whitespace-nowrap rounded px-3 py-1 text-xs" activeProps={{ className: "bg-primary text-primary-foreground" }}>{n.label}</Link>
          ))}
          <button onClick={logout} className="whitespace-nowrap rounded px-3 py-1 text-xs">Logout</button>
        </nav>
        <header className="flex flex-wrap items-center justify-between gap-3 border-b bg-card px-6 py-4">
          <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
          <div className="flex flex-wrap items-center gap-2">
            {role && (
              <span className={`rounded px-2 py-0.5 font-mono text-[11px] font-semibold uppercase ${role === "manager" ? "bg-accent/30 text-accent-foreground" : "bg-muted text-muted-foreground"}`}>
                {role === "manager" ? "Manager" : "Staff"}
              </span>
            )}
            {actions}
          </div>
        </header>
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
}

export function Stat({ label, value, hint, tone }: { label: string; value: ReactNode; hint?: string; tone?: "warn" | "ok" }) {
  return (
    <div className="rounded-lg border bg-card p-5">
      <div className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-2 text-3xl font-bold ${tone === "warn" ? "text-destructive" : tone === "ok" ? "text-success" : ""}`}>{value}</div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </div>
  );
}

export function StatusBadge({ status }: { status: DocStatus }) {
  const cls: Record<DocStatus, string> = {
    draft: "bg-muted text-muted-foreground",
    waiting: "bg-warning/20 text-accent-foreground",
    ready: "bg-chart-3/15 text-chart-3",
    done: "bg-success/15 text-success",
    canceled: "bg-destructive/10 text-destructive line-through",
  };
  return <span className={`rounded px-2 py-0.5 font-mono text-[11px] font-semibold uppercase ${cls[status]}`}>{status}</span>;
}

export function MoveBadge({ type }: { type: string }) {
  const cls: Record<string, string> = { receipt: "bg-success/15 text-success", initial: "bg-success/15 text-success", delivery: "bg-destructive/10 text-destructive", internal: "bg-chart-3/15 text-chart-3", adjustment: "bg-warning/20 text-accent-foreground" };
  return <span className={`rounded px-2 py-0.5 font-mono text-[11px] font-semibold uppercase ${cls[type] ?? "bg-muted"}`}>{type}</span>;
}

export const selectCls = "h-9 w-full rounded-md border border-input bg-background px-3 text-sm";
export const thCls = "bg-muted/50 text-left font-mono text-[11px] uppercase text-muted-foreground";
