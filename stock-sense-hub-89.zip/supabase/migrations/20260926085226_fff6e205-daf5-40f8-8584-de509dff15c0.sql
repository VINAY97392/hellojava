-- Role-based access: managers own catalog/warehouses/adjustments/cancel; staff run receipts, deliveries, transfers.

-- Track who validated each document
alter table public.documents add column if not exists validated_by uuid;

-- Helper: current user is manager
create or replace function public.is_manager()
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(auth.uid(), 'manager')
$$;

-- warehouses / locations / categories / products: read for team, write for managers only
drop policy if exists "team all" on public.warehouses;
create policy "team read" on public.warehouses for select to authenticated using (true);
create policy "managers write" on public.warehouses for insert to authenticated with check (public.is_manager());
create policy "managers update" on public.warehouses for update to authenticated using (public.is_manager()) with check (public.is_manager());
create policy "managers delete" on public.warehouses for delete to authenticated using (public.is_manager());

drop policy if exists "team all" on public.locations;
create policy "team read" on public.locations for select to authenticated using (true);
create policy "managers write" on public.locations for insert to authenticated with check (public.is_manager());
create policy "managers update" on public.locations for update to authenticated using (public.is_manager()) with check (public.is_manager());
create policy "managers delete" on public.locations for delete to authenticated using (public.is_manager());

drop policy if exists "team all" on public.categories;
create policy "team read" on public.categories for select to authenticated using (true);
create policy "managers write" on public.categories for insert to authenticated with check (public.is_manager());
create policy "managers update" on public.categories for update to authenticated using (public.is_manager()) with check (public.is_manager());
create policy "managers delete" on public.categories for delete to authenticated using (public.is_manager());

drop policy if exists "team all" on public.products;
create policy "team read" on public.products for select to authenticated using (true);
create policy "managers write" on public.products for insert to authenticated with check (public.is_manager());
create policy "managers update" on public.products for update to authenticated using (public.is_manager()) with check (public.is_manager());
create policy "managers delete" on public.products for delete to authenticated using (public.is_manager());

-- documents: everyone creates receipts/deliveries/transfers; adjustments are manager-only;
-- canceling is manager-only; other edits allowed while open
drop policy if exists "team all" on public.documents;
create policy "team read" on public.documents for select to authenticated using (true);
create policy "team create" on public.documents for insert to authenticated
  with check (doc_type <> 'adjustment' or public.is_manager());
create policy "team update" on public.documents for update to authenticated
  using (status not in ('done','canceled'))
  with check (
    (status <> 'canceled' or public.is_manager())
    and (doc_type <> 'adjustment' or public.is_manager())
  );
create policy "managers delete drafts" on public.documents for delete to authenticated
  using (public.is_manager() and status = 'draft');

-- document_lines: editable while the parent document is open; adjustment lines manager-only
drop policy if exists "team all" on public.document_lines;
create policy "team read" on public.document_lines for select to authenticated using (true);
create policy "team write lines" on public.document_lines for insert to authenticated
  with check (exists (
    select 1 from public.documents d where d.id = document_id
      and d.status not in ('done','canceled')
      and (d.doc_type <> 'adjustment' or public.is_manager())
  ));
create policy "team update lines" on public.document_lines for update to authenticated
  using (exists (
    select 1 from public.documents d where d.id = document_id
      and d.status not in ('done','canceled')
      and (d.doc_type <> 'adjustment' or public.is_manager())
  ));
create policy "team delete lines" on public.document_lines for delete to authenticated
  using (exists (
    select 1 from public.documents d where d.id = document_id
      and d.status not in ('done','canceled')
      and (d.doc_type <> 'adjustment' or public.is_manager())
  ));

-- validate_document: staff may validate receipts/deliveries/transfers; adjustments manager-only; record validator
create or replace function public.validate_document(_doc uuid)
returns void language plpgsql security definer set search_path = public as $$
declare d public.documents; l record; cur numeric; delta numeric;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  select * into d from public.documents where id=_doc for update;
  if not found then raise exception 'Document not found'; end if;
  if d.status in ('done','canceled') then raise exception 'Document is already %', d.status; end if;
  if d.doc_type = 'adjustment' and not public.has_role(auth.uid(),'manager') then
    raise exception 'Only inventory managers can validate adjustments';
  end if;
  if not exists (select 1 from public.document_lines where document_id=_doc) then raise exception 'Add at least one product line'; end if;
  if d.doc_type in ('receipt','internal','adjustment') and d.dest_location_id is null then raise exception 'Destination location required'; end if;
  if d.doc_type in ('delivery','internal') and d.source_location_id is null then raise exception 'Source location required'; end if;
  for l in select dl.*, p.sku from public.document_lines dl join public.products p on p.id=dl.product_id where dl.document_id=_doc loop
    if d.doc_type = 'adjustment' then
      if l.counted is null then raise exception 'Enter counted quantity for %', l.sku; end if;
      cur := public.on_hand(l.product_id, d.dest_location_id); delta := l.counted - cur;
      if delta <> 0 then insert into public.stock_moves(product_id,location_id,quantity,move_type,reference,document_id,user_id) values (l.product_id,d.dest_location_id,delta,'adjustment',d.reference,_doc,auth.uid()); end if;
    else
      if l.quantity <= 0 then raise exception 'Quantity for % must be positive', l.sku; end if;
      if d.doc_type in ('delivery','internal') then
        cur := public.on_hand(l.product_id, d.source_location_id);
        if cur < l.quantity then raise exception 'Not enough % at source: % available, % requested', l.sku, cur, l.quantity; end if;
        insert into public.stock_moves(product_id,location_id,quantity,move_type,reference,document_id,user_id) values (l.product_id,d.source_location_id,-l.quantity,d.doc_type::text,d.reference,_doc,auth.uid());
      end if;
      if d.doc_type in ('receipt','internal') then
        insert into public.stock_moves(product_id,location_id,quantity,move_type,reference,document_id,user_id) values (l.product_id,d.dest_location_id,l.quantity,d.doc_type::text,d.reference,_doc,auth.uid());
      end if;
    end if;
  end loop;
  perform set_config('app.validating','on',true);
  update public.documents set status='done', validated_at=now(), validated_by=auth.uid() where id=_doc;
  perform set_config('app.validating','off',true);
end $$;

-- set_initial_stock: manager-only (it writes stock without a document)
create or replace function public.set_initial_stock(_product uuid, _location uuid, _qty numeric)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  if not public.has_role(auth.uid(),'manager') then raise exception 'Only inventory managers can set initial stock'; end if;
  if _qty <= 0 then return; end if;
  if exists (select 1 from public.stock_moves where product_id=_product) then raise exception 'Product already has stock history'; end if;
  insert into public.stock_moves(product_id,location_id,quantity,move_type,reference,user_id) values (_product,_location,_qty,'initial','INITIAL',auth.uid());
end $$;