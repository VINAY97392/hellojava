import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useMaster, useRefresh, useRole } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/warehouses")({
  head: () => ({ meta: [
    { title: "Warehouses — StockSense" },
    { name: "description", content: "Manage warehouses and their stock locations." },
    { property: "og:title", content: "Warehouses — StockSense" },
    { property: "og:description", content: "Manage warehouses and their stock locations." },
  ] }),
  component: Warehouses,
});

function Warehouses() {
  const m = useMaster();
  const refresh = useRefresh();
  const { isManager } = useRole();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [address, setAddress] = useState("");
  const [locDraft, setLocDraft] = useState<Record<string, string>>({});
  if (!m.data) return <AppShell title="Warehouses"><p className="text-muted-foreground">Loading…</p></AppShell>;
  const { warehouses, locations, byLoc, products } = m.data;

  async function addWh(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !code.trim()) return void toast.error("Name and short code are required");
    const r = await supabase.from("warehouses").insert({ name: name.trim(), code: code.trim().toUpperCase(), address: address.trim() || null }).select().single();
    if (r.error) return void toast.error(r.error.message);
    await supabase.from("locations").insert({ warehouse_id: r.data.id, name: "Stock" });
    setName(""); setCode(""); setAddress(""); toast.success("Warehouse added"); refresh();
  }
  async function addLoc(wid: string) {
    const n = locDraft[wid]?.trim();
    if (!n) return;
    const r = await supabase.from("locations").insert({ warehouse_id: wid, name: n });
    if (r.error) return void toast.error(r.error.message);
    setLocDraft({ ...locDraft, [wid]: "" }); refresh();
  }
  const units = (locId: string) => products.reduce((s, p) => s + (byLoc[p.id]?.[locId] ?? 0), 0);

  return (
    <AppShell title="Warehouses">
      {isManager && (
        <form onSubmit={addWh} className="mb-6 flex flex-wrap items-end gap-2 rounded-lg border bg-card p-4">
          <Input className="w-56" placeholder="Warehouse name" value={name} onChange={(e) => setName(e.target.value)} />
          <Input className="w-28" placeholder="Code (WH3)" value={code} onChange={(e) => setCode(e.target.value)} />
          <Input className="w-72" placeholder="Address (optional)" value={address} onChange={(e) => setAddress(e.target.value)} />
          <Button type="submit"><Plus className="h-4 w-4" />Add warehouse</Button>
        </form>
      )}
      <div className="grid gap-4 md:grid-cols-2">
        {warehouses.map((w) => (
          <div key={w.id} className="rounded-lg border bg-card p-5">
            <div className="flex items-baseline justify-between"><h2 className="text-lg font-bold">{w.name}</h2><span className="font-mono text-xs text-muted-foreground">{w.code}</span></div>
            {w.address && <p className="text-xs text-muted-foreground">{w.address}</p>}
            <ul className="mt-4 space-y-1 text-sm">
              {locations.filter((l) => l.warehouse_id === w.id).map((l) => (
                <li key={l.id} className="flex justify-between border-b pb-1"><span>{l.name}</span><span className="font-mono text-xs text-muted-foreground">{units(l.id)} units</span></li>
              ))}
            </ul>
            {isManager && (
              <div className="mt-3 flex gap-2">
                <Input className="h-8" placeholder="New location e.g. Rack C" value={locDraft[w.id] ?? ""} onChange={(e) => setLocDraft({ ...locDraft, [w.id]: e.target.value })} />
                <Button size="sm" variant="outline" onClick={() => addLoc(w.id)}>Add</Button>
              </div>
            )}
          </div>
        ))}
      </div>
    </AppShell>
  );
}
