import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type T = Database["public"]["Tables"];
export type Warehouse = T["warehouses"]["Row"];
export type Location = T["locations"]["Row"];
export type Category = T["categories"]["Row"];
export type Product = T["products"]["Row"];
export type Doc = T["documents"]["Row"];
export type DocLine = T["document_lines"]["Row"];
export type Move = T["stock_moves"]["Row"];
export type DocType = Database["public"]["Enums"]["doc_type"];
export type DocStatus = Database["public"]["Enums"]["doc_status"];

export const DOC_TYPES: { type: DocType; slug: string; label: string; short: string }[] = [
  { type: "receipt", slug: "receipts", label: "Receipts", short: "Receipt" },
  { type: "delivery", slug: "deliveries", label: "Delivery Orders", short: "Delivery" },
  { type: "internal", slug: "transfers", label: "Internal Transfers", short: "Transfer" },
  { type: "adjustment", slug: "adjustments", label: "Inventory Adjustments", short: "Adjustment" },
];
export const STATUSES: DocStatus[] = ["draft", "waiting", "ready", "done", "canceled"];

function must<D>(r: { data: D | null; error: { message: string } | null }): D {
  if (r.error) throw new Error(r.error.message);
  return r.data as D;
}

export function useMaster() {
  return useQuery({
    queryKey: ["master"],
    queryFn: async () => {
      const [w, l, c, p, s] = await Promise.all([
        supabase.from("warehouses").select("*").order("name"),
        supabase.from("locations").select("*").order("name"),
        supabase.from("categories").select("*").order("name"),
        supabase.from("products").select("*").order("name"),
        supabase.from("stock_levels").select("*"),
      ]);
      const warehouses = must(w), locations = must(l), categories = must(c), products = must(p), levels = must(s);
      const onHand: Record<string, number> = {};
      const byLoc: Record<string, Record<string, number>> = {};
      for (const r of levels) {
        if (!r.product_id || !r.location_id) continue;
        const q = Number(r.quantity ?? 0);
        onHand[r.product_id] = (onHand[r.product_id] ?? 0) + q;
        (byLoc[r.product_id] ??= {})[r.location_id] = q;
      }
      const locName = (id?: string | null) => {
        const loc = locations.find((x) => x.id === id);
        if (!loc) return "—";
        const wh = warehouses.find((x) => x.id === loc.warehouse_id);
        return `${wh?.code ?? ""}/${loc.name}`;
      };
      return { warehouses, locations, categories, products, onHand, byLoc, locName };
    },
  });
}

export function useDocuments() {
  return useQuery({
    queryKey: ["documents"],
    queryFn: async () => must(await supabase.from("documents").select("*, document_lines(*)").order("created_at", { ascending: false })),
  });
}

export function useMoves() {
  return useQuery({
    queryKey: ["moves"],
    queryFn: async () => must(await supabase.from("stock_moves").select("*").order("created_at", { ascending: false }).limit(1000)),
  });
}

export function useProfiles() {
  return useQuery({
    queryKey: ["profiles"],
    queryFn: async () => {
      const [p, r] = await Promise.all([supabase.from("profiles").select("*"), supabase.from("user_roles").select("*")]);
      const roles = must(r);
      return must(p).map((x) => ({ ...x, role: roles.find((y) => y.user_id === x.id)?.role ?? "staff" }));
    },
  });
}

export type Role = "manager" | "staff";

/** Current user's role. Returns undefined while loading — treat as staff (least privilege). */
export function useRole(): { role: Role | undefined; isManager: boolean; loading: boolean } {
  const q = useQuery({
    queryKey: ["my-role"],
    queryFn: async () => {
      const me = (await supabase.auth.getUser()).data.user?.id;
      if (!me) return "staff" as Role;
      const r = await supabase.from("user_roles").select("role").eq("user_id", me);
      return (must(r)[0]?.role ?? "staff") as Role;
    },
    staleTime: 60_000,
  });
  return { role: q.data, isManager: q.data === "manager", loading: q.isLoading };
}

export function useRefresh() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries();
}

export function exportCsv(name: string, rows: (string | number | null | undefined)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  a.download = name;
  a.click();
}

export const fmtDate = (ts: string) => new Date(ts).toLocaleString("en-GB", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
export const fmtMoney = (n: number) => n.toLocaleString("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });
