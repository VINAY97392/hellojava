import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Boxes, ArrowDownToLine, ArrowUpFromLine, ArrowLeftRight, ClipboardCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "StockSense — Inventory Management System" },
    { name: "description", content: "Replace registers and spreadsheets with real-time receipts, deliveries, transfers and stock adjustments." },
    { property: "og:title", content: "StockSense — Inventory Management System" },
    { property: "og:description", content: "Replace registers and spreadsheets with real-time receipts, deliveries, transfers and stock adjustments." },
  ] }),
  component: Landing,
});

function Landing() {
  const navigate = useNavigate();
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { if (data.session) navigate({ to: "/dashboard", replace: true }); });
  }, [navigate]);
  const flow = [
    { icon: ArrowDownToLine, t: "Receive", d: "100 kg Steel from vendor → +100" },
    { icon: ArrowLeftRight, t: "Transfer", d: "Main Store → Production Rack" },
    { icon: ArrowUpFromLine, t: "Deliver", d: "20 kg to customer → −20" },
    { icon: ClipboardCheck, t: "Adjust", d: "3 kg damaged → −3" },
  ];
  return (
    <div className="min-h-screen bg-primary text-primary-foreground">
      <div className="mx-auto flex max-w-5xl flex-col px-6 py-10">
        <div className="flex items-center gap-2"><div className="grid h-9 w-9 place-items-center rounded-md bg-accent text-accent-foreground"><Boxes className="h-5 w-5" /></div><span className="text-lg font-bold">StockSense</span></div>
        <h1 className="mt-20 max-w-3xl text-5xl font-bold leading-tight md:text-6xl">Every unit, every move, <span className="text-accent">on the ledger.</span></h1>
        <p className="mt-6 max-w-xl text-lg opacity-70">One place for inventory managers and warehouse staff to receive, pick, move and count stock — in real time, across every warehouse.</p>
        <div className="mt-8 flex gap-3">
          <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90"><Link to="/auth">Sign in</Link></Button>
          <Button asChild size="lg" variant="outline" className="border-primary-foreground/30 bg-transparent text-primary-foreground hover:bg-primary-foreground/10"><Link to="/auth" search={{ mode: "signup" }}>Create account</Link></Button>
        </div>
        <div className="mt-20 grid gap-3 md:grid-cols-4">
          {flow.map((f, i) => (
            <div key={f.t} className="rounded-lg border border-primary-foreground/15 p-5">
              <div className="font-mono text-xs opacity-50">STEP {i + 1}</div>
              <f.icon className="mt-3 h-6 w-6 text-accent" />
              <div className="mt-2 font-semibold">{f.t}</div>
              <div className="text-sm opacity-60">{f.d}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
