import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Download, Plus, Search } from "lucide-react";
import { AppShell, selectCls, thCls } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { exportCsv, useMaster, useRefresh, useRole, type Product } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/products")({
  head: () => ({ meta: [
    { title: "Products — StockSense" },
    { name: "description", content: "Product catalog with SKUs, categories, reordering rules and stock per location." },
    { property: "og:title", content: "Products — StockSense" },
    { property: "og:description", content: "Product catalog with SKUs, categories, reordering rules and stock per location." },
  ] }),
  component: Products,
});

type Form = Partial<Product> & { initialQty?: string; initialLoc?: string; newCategory?: string };

function Products() {
  const m = useMaster();
  const refresh = useRefresh();
  const { isManager } = useRole();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const [form, setForm] = useState<Form | null>(null);
  const [view, setView] = useState<Product | null>(null);
  if (!m.data) return <AppShell title="Products"><p className="text-muted-foreground">{m.error?.message ?? "Loading…"}</p></AppShell>;
  const { products, categories, onHand, byLoc, locations, locName } = m.data;
  const catName = (id: string | null) => categories.find((c) => c.id === id)?.name ?? "—";
  const rows = products.filter((p) => (cat === "all" || p.category_id === cat) && `${p.sku} ${p.name}`.toLowerCase().includes(q.toLowerCase()));

  async function save(e: React.FormEvent) {
    e.preventDefault();
    const f = form!;
    if (!f.sku?.trim() || !f.name?.trim()) return void toast.error("Name and SKU are required");
    let category_id = f.category_id ?? null;
    if (f.newCategory?.trim()) {
      const r = await supabase.from("categories").insert({ name: f.newCategory.trim() }).select().single();
      if (r.error) return void toast.error(r.error.message);
      category_id = r.data.id;
    }
    const payload = { sku: f.sku.trim().toUpperCase(), name: f.name.trim(), category_id, uom: f.uom || "pcs", unit_cost: Number(f.unit_cost ?? 0), reorder_min: Number(f.reorder_min ?? 0), reorder_qty: Number(f.reorder_qty ?? 0) };
    const r = f.id ? await supabase.from("products").update(payload).eq("id", f.id).select().single() : await supabase.from("products").insert(payload).select().single();
    if (r.error) return void toast.error(r.error.message.includes("duplicate") ? "That SKU already exists" : r.error.message);
    const qty = Number(f.initialQty ?? 0);
    if (!f.id && qty > 0) {
      if (!f.initialLoc) return void toast.error("Choose a location for initial stock");
      const s = await supabase.rpc("set_initial_stock", { _product: r.data.id, _location: f.initialLoc, _qty: qty });
      if (s.error) toast.error(s.error.message);
    }
    toast.success("Product saved");
    setForm(null);
    refresh();
  }

  return (
    <AppShell title="Products" actions={<>
      <Button variant="outline" onClick={() => exportCsv("products.csv", [["SKU", "Name", "Category", "UoM", "On hand", "Reorder min", "Reorder qty"], ...rows.map((p) => [p.sku, p.name, catName(p.category_id), p.uom, onHand[p.id] ?? 0, p.reorder_min, p.reorder_qty])])}><Download className="h-4 w-4" />Export</Button>
      {isManager && <Button onClick={() => setForm({ uom: "pcs", reorder_min: 0, reorder_qty: 0, unit_cost: 0, initialLoc: locations[0]?.id ?? "" })}><Plus className="h-4 w-4" />New product</Button>}
    </>}>
      <div className="mb-4 flex flex-wrap gap-3">
        <div className="relative w-full max-w-xs"><Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><Input className="pl-9" placeholder="Search SKU or name…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="flex flex-wrap gap-1">
          <Button size="sm" variant={cat === "all" ? "default" : "outline"} onClick={() => setCat("all")}>All</Button>
          {categories.map((c) => <Button key={c.id} size="sm" variant={cat === c.id ? "default" : "outline"} onClick={() => setCat(c.id)}>{c.name}</Button>)}
        </div>
      </div>
      <div className="overflow-x-auto rounded-lg border bg-card">
        <table className="w-full text-sm">
          <thead className={thCls}><tr><th className="p-3">SKU</th><th>Name</th><th>Category</th><th className="text-right">On hand</th><th className="text-right">Reorder min</th><th className="text-right">Reorder qty</th><th className="p-3">Status</th><th /></tr></thead>
          <tbody>
            {rows.map((p) => {
              const s = onHand[p.id] ?? 0;
              const st = s <= 0 ? ["Out", "bg-destructive/10 text-destructive"] : s <= Number(p.reorder_min) ? ["Low", "bg-warning/20 text-accent-foreground"] : ["OK", "bg-success/15 text-success"];
              return (
                <tr key={p.id} className="cursor-pointer border-t hover:bg-muted/40" onClick={() => setView(p)}>
                  <td className="p-3 font-mono text-xs">{p.sku}</td><td className="font-medium">{p.name}</td><td>{catName(p.category_id)}</td>
                  <td className="text-right font-mono">{s} <span className="text-muted-foreground">{p.uom}</span></td>
                  <td className="text-right font-mono text-muted-foreground">{Number(p.reorder_min)}</td>
                  <td className="text-right font-mono text-muted-foreground">{Number(p.reorder_qty)}</td>
                  <td className="p-3"><span className={`rounded px-2 py-0.5 text-xs font-semibold ${st[1]}`}>{st[0]}</span></td>
                  <td className="pr-3">{isManager && <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); setForm(p); }}>Edit</Button>}</td>
                </tr>
              );
            })}
            {!rows.length && <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">No products match.</td></tr>}
          </tbody>
        </table>
      </div>

      <Dialog open={!!view} onOpenChange={(o) => !o && setView(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{view?.name} · stock by location</DialogTitle></DialogHeader>
          {view && (
            <div className="space-y-2 text-sm">
              {Object.entries(byLoc[view.id] ?? {}).filter(([, q]) => q !== 0).map(([loc, q]) => (
                <div key={loc} className="flex justify-between border-b pb-1"><span>{locName(loc)}</span><span className="font-mono">{q} {view.uom}</span></div>
              ))}
              {!Object.values(byLoc[view.id] ?? {}).some((q) => q !== 0) && <p className="text-muted-foreground">No stock at any location.</p>}
              <div className="flex justify-between pt-2 font-semibold"><span>Total</span><span className="font-mono">{onHand[view.id] ?? 0} {view.uom}</span></div>
              <p className="pt-2 text-xs text-muted-foreground">Reordering rule: when stock falls to {Number(view.reorder_min)} {view.uom}, reorder {Number(view.reorder_qty)} {view.uom}.</p>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={!!form} onOpenChange={(o) => !o && setForm(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{form?.id ? "Edit product" : "New product"}</DialogTitle></DialogHeader>
          {form && (
            <form onSubmit={save} className="grid grid-cols-2 gap-3">
              <div><Label>Name</Label><Input value={form.name ?? ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><Label>SKU / Code</Label><Input value={form.sku ?? ""} onChange={(e) => setForm({ ...form, sku: e.target.value })} /></div>
              <div><Label>Category</Label>
                <select className={selectCls} value={form.category_id ?? ""} onChange={(e) => setForm({ ...form, category_id: e.target.value || null })}>
                  <option value="">— None —</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div><Label>…or new category</Label><Input value={form.newCategory ?? ""} onChange={(e) => setForm({ ...form, newCategory: e.target.value })} placeholder="e.g. Electronics" /></div>
              <div><Label>Unit of measure</Label><Input value={form.uom ?? ""} onChange={(e) => setForm({ ...form, uom: e.target.value })} /></div>
              <div><Label>Unit cost</Label><Input type="number" step="0.01" value={form.unit_cost ?? 0} onChange={(e) => setForm({ ...form, unit_cost: Number(e.target.value) })} /></div>
              <div><Label>Reorder minimum</Label><Input type="number" value={form.reorder_min ?? 0} onChange={(e) => setForm({ ...form, reorder_min: Number(e.target.value) })} /></div>
              <div><Label>Reorder quantity</Label><Input type="number" value={form.reorder_qty ?? 0} onChange={(e) => setForm({ ...form, reorder_qty: Number(e.target.value) })} /></div>
              {!form.id && (<>
                <div><Label>Initial stock (optional)</Label><Input type="number" min="0" value={form.initialQty ?? ""} onChange={(e) => setForm({ ...form, initialQty: e.target.value })} /></div>
                <div><Label>At location</Label><select className={selectCls} value={form.initialLoc ?? ""} onChange={(e) => setForm({ ...form, initialLoc: e.target.value })}>{locations.map((l) => <option key={l.id} value={l.id}>{locName(l.id)}</option>)}</select></div>
              </>)}
              <Button type="submit" className="col-span-2">Save</Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
