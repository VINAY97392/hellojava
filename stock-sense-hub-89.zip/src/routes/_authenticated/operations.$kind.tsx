import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, Search } from "lucide-react";
import { AppShell, StatusBadge, thCls } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { DOC_TYPES, STATUSES, useDocuments, useMaster, useProfiles, useRole } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/operations/$kind")({
  beforeLoad: ({ params }) => { if (!DOC_TYPES.some((t) => t.slug === params.kind)) throw notFound(); },
  head: ({ params }) => {
    const t = DOC_TYPES.find((x) => x.slug === params.kind)?.label ?? "Operations";
    return { meta: [
      { title: `${t} — StockSense` },
      { name: "description", content: `Create, track and validate ${t.toLowerCase()}.` },
      { property: "og:title", content: `${t} — StockSense` },
      { property: "og:description", content: `Create, track and validate ${t.toLowerCase()}.` },
    ] };
  },
  component: OpsList,
});

function OpsList() {
  const { kind } = Route.useParams();
  const t = DOC_TYPES.find((x) => x.slug === kind)!;
  const m = useMaster();
  const d = useDocuments();
  const prof = useProfiles();
  const { isManager, loading: roleLoading } = useRole();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");

  async function create() {
    const me = (await supabase.auth.getUser()).data.user?.id;
    const myWh = prof.data?.find((p) => p.id === me)?.default_warehouse_id;
    const firstLoc = m.data?.locations.find((l) => !myWh || l.warehouse_id === myWh)?.id ?? null;
    const r = await supabase.from("documents").insert({
      doc_type: t.type,
      source_location_id: t.type === "delivery" || t.type === "internal" ? firstLoc : null,
      dest_location_id: t.type !== "delivery" ? firstLoc : null,
    }).select().single();
    if (r.error) return void toast.error(r.error.message);
    navigate({ to: "/documents/$id", params: { id: r.data.id } });
  }

  const docs = (d.data ?? []).filter((x) => x.doc_type === t.type && (status === "all" || x.status === status) && `${x.reference} ${x.partner ?? ""}`.toLowerCase().includes(q.toLowerCase()));
  const locName = m.data?.locName ?? (() => "");

  return (
    <AppShell title={t.label} actions={(t.type !== "adjustment" || isManager) ? <Button onClick={create}><Plus className="h-4 w-4" />New {t.short.toLowerCase()}</Button> : undefined}>
      {t.type === "adjustment" && !isManager && !roleLoading && (
        <p className="mb-4 rounded-md border bg-muted/40 px-4 py-2 text-sm text-muted-foreground">Only inventory managers can create and validate adjustments. You can view them here.</p>
      )}
      <div className="mb-4 flex flex-wrap gap-3">
        <div className="relative w-full max-w-xs"><Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><Input className="pl-9" placeholder="Search reference or partner…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="flex flex-wrap gap-1">
          {["all", ...STATUSES].map((s) => <Button key={s} size="sm" variant={status === s ? "default" : "outline"} onClick={() => setStatus(s)} className="capitalize">{s}</Button>)}
        </div>
      </div>
      <div className="overflow-x-auto rounded-lg border bg-card">
        <table className="w-full text-sm">
          <thead className={thCls}><tr><th className="p-3">Reference</th>{t.type !== "internal" && t.type !== "adjustment" && <th>{t.type === "receipt" ? "Supplier" : "Customer"}</th>}<th>From</th><th>To</th><th>Scheduled</th><th className="text-right">Lines</th><th className="p-3">Status</th></tr></thead>
          <tbody>
            {docs.map((x) => (
              <tr key={x.id} className="border-t hover:bg-muted/40">
                <td className="p-3 font-mono text-xs"><Link to="/documents/$id" params={{ id: x.id }} className="underline">{x.reference}</Link></td>
                {t.type !== "internal" && t.type !== "adjustment" && <td>{x.partner ?? "—"}</td>}
                <td className="text-xs text-muted-foreground">{x.source_location_id ? locName(x.source_location_id) : t.type === "receipt" ? "Vendor" : "—"}</td>
                <td className="text-xs text-muted-foreground">{x.dest_location_id ? locName(x.dest_location_id) : t.type === "delivery" ? "Customer" : "—"}</td>
                <td className="font-mono text-xs">{x.scheduled_date}</td>
                <td className="text-right font-mono">{x.document_lines.length}</td>
                <td className="p-3"><StatusBadge status={x.status} /></td>
              </tr>
            ))}
            {!docs.length && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">{d.isLoading ? "Loading…" : "Nothing here yet."}</td></tr>}
          </tbody>
        </table>
      </div>
    </AppShell>
  );
}
